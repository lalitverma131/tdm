package com.test.backend.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ddm_metadata")
public class DDMMetadata {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "table_name", nullable = false)
	private String tableName;

	@Column(name = "col_name", nullable = false)
	private String columnName;

	@Column(name = "order_by", nullable = false)
	private Integer orderBy = 1;

	@Column(name = "alias")
	private String alias;

	@Column(name = "server_active")
	private Boolean serverActive = true;

	@ManyToOne
	@JoinColumn(name = "server_id")
	private DDMServer server;

	@OneToMany(mappedBy = "metadata", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<DDMMetadataFunction> function;
}

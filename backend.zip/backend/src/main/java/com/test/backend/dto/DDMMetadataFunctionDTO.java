package com.test.backend.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class DDMMetadataFunctionDTO {

	private Long id;

	@NotNull
	private String functionName;

	private Integer orderBy = 1;

	private Boolean serverActive = true;

	private DDMMetadataDTO metadata;

	private List<DDMMetadataFunctionParamaterDTO> parameter;
}

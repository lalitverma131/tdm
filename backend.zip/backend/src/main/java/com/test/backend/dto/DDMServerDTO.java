package com.test.backend.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class DDMServerDTO {

	private Long id;

	private String name;

	@NotNull
	private String hostname;

	@NotNull
	private String port;

	private String tags;

	private Integer status;

	private Boolean isActive;

	private List<DDMMetadataDTO> metadata;
}

package com.test.backend.dto;

import lombok.Data;

@Data
public class DDMMetadataFunctionParamaterDTO {

	private Long id;

	private String parameterValue;

	private String parameterType;

	private Integer orderBy = 1;

	private Boolean serverActive = true;

	private DDMMetadataFunctionDTO parameter;
}

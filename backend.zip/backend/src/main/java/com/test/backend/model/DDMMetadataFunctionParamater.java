package com.test.backend.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ddm_function_parameter")
public class DDMMetadataFunctionParamater {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "parameter_value")
	private String parameterValue;

	@Column(name = "parameter_type")
	private String parameterType;

	@Column(name = "order_by")
	private Integer orderBy = 1;

	@Column(name = "server_active")
	private Boolean serverActive = true;

	@ManyToOne
	@JoinColumn(name = "function_id")
	private DDMMetadataFunction parameter;
}

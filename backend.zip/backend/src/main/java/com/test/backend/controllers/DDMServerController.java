package com.test.backend.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.backend.dao.DDMServerDAO;
import com.test.backend.dto.DDMServerDTO;
import com.test.backend.model.DDMServer;

@RestController
public class DDMServerController {

	@Autowired
	private DDMServerDAO ddmServerDAO;

	private ModelMapper mapper = new ModelMapper();

	@RequestMapping(value = "/addserver", method = RequestMethod.GET)
	public ResponseEntity<Response> addServer(@RequestBody DDMServerDTO ddmServerDTO) {
		Response response = new Response("Server Created",
				ddmServerDAO.save(mapper.map(ddmServerDTO, DDMServer.class)));
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}
}

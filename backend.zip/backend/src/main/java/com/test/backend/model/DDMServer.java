package com.test.backend.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

import lombok.Data;

@Data
@Entity
@Table(name = "ddm_server")
public class DDMServer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "name", unique = true)
	private String name;

	@Column(name = "hostname", nullable = false)
	private String hostname;

	@Column(name = "port", nullable = false)
	private String port;

	@Column(name = "tags")
	private String tags;

	@Column(name = "status")
	private Integer status;

	@Column(name = "is_active")
	private Boolean isActive;

	@OneToMany(mappedBy = "server", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<DDMMetadata> metadata;
}

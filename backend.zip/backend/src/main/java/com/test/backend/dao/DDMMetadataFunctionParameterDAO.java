package com.test.backend.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.backend.model.DDMMetadataFunctionParamater;

public interface DDMMetadataFunctionParameterDAO extends JpaRepository<DDMMetadataFunctionParamater, Long> {

}

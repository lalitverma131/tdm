package com.test.backend.controllers;

import lombok.Data;

@Data
public class Response {

	private String text;
	private Object data;

	public Response(String text, Object data) {
		this.text = text;
		this.data = data;
	}
}
